#pragma once
#include "types.h"
#include "vfs.h"
// process level manager

#define MAX_FDS 16  // or however many per process

// File descriptor table (lives in process_t)
typedef struct fd_table {
    file_t *files[MAX_FDS];
} fd_table_t;

// Function declarations
int   fd_alloc(fd_table_t *table, file_t *f);  // returns fd number
file_t *fd_get(fd_table_t *table, int fd);
void  fd_close(fd_table_t *table, int fd);
void  fd_init(fd_table_t *table);  // sets up stdin/stdout/stderr
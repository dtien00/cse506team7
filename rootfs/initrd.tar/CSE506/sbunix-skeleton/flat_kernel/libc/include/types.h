#ifndef TYPES_H
#define TYPES_H

typedef unsigned char      uint8_t;
typedef unsigned short     uint16_t;
typedef unsigned int       uint32_t;
typedef unsigned long long uint64_t;
typedef long long          int64_t;
typedef int                int32_t;
typedef short              int16_t;
typedef signed char        int8_t;

typedef uint64_t  uintptr_t;   // RISC-V 64-bit
typedef int64_t   intptr_t;
typedef uint64_t  size_t;
typedef int64_t   ssize_t;

#endif // TYPES_H